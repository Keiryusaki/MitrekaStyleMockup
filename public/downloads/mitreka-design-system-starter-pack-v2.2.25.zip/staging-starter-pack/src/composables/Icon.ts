import { Icon, iconRegistry, type IconName } from "@keiryusaki/mitreka-ui";

export { Icon, iconRegistry };
export type { IconName };
