<script setup lang="ts">
import { PageHeader } from "@keiryusaki/mitreka-ui/vue";
</script>

<template>
  <div class="space-y-4">
    <PageHeader
      category="Guides"
      title="Theme Guide"
      description="Panduan set theme langsung dari codingan tanpa theme picker di topbar."
    />

    <section class="card p-4 space-y-3">
      <h2 class="text-base font-semibold">1) Set default theme saat app start</h2>
      <p class="text-sm opacity-80">
        Gunakan store UI untuk set mode awal dari kode, misalnya selalu light saat boot.
      </p>
      <pre class="code"><code>import { useUi } from "@/stores/ui";

const ui = useUi();
ui.setTheme("mitrekalight"); // atau "mitrekadark"</code></pre>
    </section>

    <section class="card p-4 space-y-3">
      <h2 class="text-base font-semibold">2) Toggle light/dark dari komponen</h2>
      <p class="text-sm opacity-80">
        Untuk switch sederhana, panggil action yang sudah ada di store.
      </p>
      <pre class="code"><code>const ui = useUi();
ui.toggleTheme();</code></pre>
    </section>

    <section class="card p-4 space-y-3">
      <h2 class="text-base font-semibold">3) Apply custom theme hasil Theme Builder</h2>
      <p class="text-sm opacity-80">
        Simpan CSS output Theme Builder ke file terpisah lalu import setelah
        <code>@keiryusaki/mitreka-ui/css</code> agar token ter-override.
      </p>
      <pre class="code"><code>/* src/assets/tailwind.css */
@import "tailwindcss";
@import "@keiryusaki/mitreka-ui/css";
@import "./theme-overrides.css";</code></pre>
      <p class="text-xs opacity-70">
        Rekomendasi: commit file override per produk supaya tema konsisten lintas environment.
      </p>
    </section>
  </div>
</template>
