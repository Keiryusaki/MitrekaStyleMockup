# Staging Starter Pack (Lean)

Tujuan folder ini:
- baseline starter pack yang benar-benar ramping,
- audit file mentah dulu sebelum `npm install`,
- semua komponen UI konsumsi dari package `@keiryusaki/mitreka-ui/vue` (tanpa copas komponen DS).

## Definisi "Ramping" (Final)
- Tidak ada file tambahan yang tidak dipakai.
- Tidak ada copy manual komponen yang sudah tersedia di package `@keiryusaki/mitreka-ui`.
- Struktur lokal hanya untuk kebutuhan app shell (layout, routing, halaman sample), bukan duplikasi component library.
- Jika komponen sudah tersedia di package, wajib import dari package.

## Cakupan Halaman
- `Dashboard`
- `Mockup Pages`
  - `AG Grid`
  - `Project Budgeting`
- `Components`
  - `Colors`
  - `Button`
  - `Input`
  - `Skeleton`
  - `Loading`
  - `Theme Guide`
- `Auth Pages`
  - `Sign In`
  - `Register`
  - `Forgot Password`
  - `Reset Password`
- Layout:
  - `Topbar`
  - `Sidebar`
  - `Footer`

## Aturan
- `src/assets/tailwind.css` hanya:
  - `@import "tailwindcss";`
  - `@import "@keiryusaki/mitreka-ui/css";`
  - `@source "../../node_modules/@keiryusaki/mitreka-ui/dist/**/*.js";`
- Dilarang import komponen package dari `@/components/*`.
- Tidak ada `node_modules` dan `dist` di folder ini (mentah).

## Audit cepat (setelah install)
```bash
rg -n "@/components/" src/pages
```
Hasil ideal: kosong.

Audit tambahan:
```bash
rg -n "from \"@keiryusaki/mitreka-ui/vue\"" src/pages
```
Hasil ideal: halaman sample mengandalkan import package, bukan komponen copy lokal.
