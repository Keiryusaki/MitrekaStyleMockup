import { createRouter, createWebHistory, type RouteRecordRaw } from "vue-router";
import Dashboard from "@/pages/Dashboard.vue";

const routes: RouteRecordRaw[] = [
  { path: "/", component: Dashboard, meta: { breadcrumbs: [] } },
  {
    path: "/colors",
    component: () => import("@/pages/Colors/Colors.vue"),
    meta: { breadcrumbs: [{ label: "Components", href: "/colors" }, { label: "Colors" }] },
  },
  {
    path: "/button",
    component: () => import("@/pages/Buttons/Buttons.vue"),
    meta: { breadcrumbs: [{ label: "Components", href: "/button" }, { label: "Button" }] },
  },
  {
    path: "/input",
    component: () => import("@/pages/Input/Input.vue"),
    meta: { breadcrumbs: [{ label: "Components", href: "/input" }, { label: "Input" }] },
  },
  {
    path: "/skeleton",
    component: () => import("@/pages/Skeleton/Skeleton.vue"),
    meta: { breadcrumbs: [{ label: "Components", href: "/skeleton" }, { label: "Skeleton" }] },
  },
  {
    path: "/loading",
    component: () => import("@/pages/Loading/Loading.vue"),
    meta: { breadcrumbs: [{ label: "Components", href: "/loading" }, { label: "Loading" }] },
  },
  {
    path: "/theme-guide",
    component: () => import("@/pages/ThemeGuide/ThemeGuide.vue"),
    meta: { breadcrumbs: [{ label: "Guides", href: "/theme-guide" }, { label: "Theme Guide" }] },
  },
  {
    path: "/aggrid",
    component: () => import("@/pages/Aggrid/AGGridDemo.vue"),
    meta: { breadcrumbs: [{ label: "Mockup Pages", href: "/aggrid" }, { label: "AG Grid" }] },
  },
  {
    path: "/project-budgeting",
    component: () => import("@/pages/Aggrid/ProjectBudgeting.vue"),
    meta: {
      breadcrumbs: [{ label: "Mockup Pages", href: "/project-budgeting" }, { label: "Project Budgeting" }],
      hideBreadcrumbs: true,
    },
  },
  { path: "/auth/signin", component: () => import("@/pages/Auth/SignIn.vue"), meta: { layout: "blank" } },
  { path: "/auth/register", component: () => import("@/pages/Auth/Register.vue"), meta: { layout: "blank" } },
  { path: "/auth/forgot", component: () => import("@/pages/Auth/ForgotPassword.vue"), meta: { layout: "blank" } },
  { path: "/auth/reset", component: () => import("@/pages/Auth/ResetPassword.vue"), meta: { layout: "blank" } },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, _from, savedPosition) {
    if (savedPosition) return savedPosition;
    if (to.hash) return { el: to.hash, behavior: "smooth" };
    return { top: 0 };
  },
});

router.afterEach((to) => {
  document.title = to.meta.title ? `${to.meta.title} · Consumer Test` : "Consumer Test";
});

export default router;
