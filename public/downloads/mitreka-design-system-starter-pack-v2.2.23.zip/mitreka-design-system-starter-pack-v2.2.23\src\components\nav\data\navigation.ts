export type IconName =
  | "dashboard"
  | "layout"
  | "component"
  | "lock"
  | "chevron-right"
  | "chevron-left"
  | "dot";

export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  to?: string;
  children?: NavItem[];
  exact?: boolean;
};

export const NAV: NavItem[] = [
  { id: "dash", label: "Dashboard", icon: "dashboard", to: "/", exact: true },
  {
    id: "mockup",
    label: "Mockup Pages",
    icon: "layout",
    children: [
      { id: "aggrid", label: "AG Grid", to: "/aggrid" },
      { id: "project-budgeting", label: "Project Budgeting", to: "/project-budgeting" },
    ],
  },
  {
    id: "components",
    label: "Components",
    icon: "component",
    children: [
      { id: "colors", label: "Colors", to: "/colors" },
      { id: "button", label: "Button", to: "/button" },
      { id: "input", label: "Input", to: "/input" },
      { id: "skeleton", label: "Skeleton", to: "/skeleton" },
      { id: "loading", label: "Loading", to: "/loading" },
      { id: "theme-guide", label: "Theme Guide", to: "/theme-guide" },
    ],
  },
  {
    id: "auth",
    label: "Auth Pages",
    icon: "lock",
    children: [
      { id: "auth-signin", label: "Sign In", to: "/auth/signin" },
      { id: "auth-register", label: "Register", to: "/auth/register" },
      { id: "auth-forgot", label: "Forgot Password", to: "/auth/forgot" },
      { id: "auth-reset", label: "Reset Password", to: "/auth/reset" },
    ],
  },
];
