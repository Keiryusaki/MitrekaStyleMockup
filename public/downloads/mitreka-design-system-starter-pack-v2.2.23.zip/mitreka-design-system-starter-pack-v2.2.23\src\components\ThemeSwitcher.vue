<script setup lang="ts">
import { ThemeSwitcher as BaseThemeSwitcher } from "@keiryusaki/mitreka-ui/vue";
</script>

<template>
  <BaseThemeSwitcher />
</template>
