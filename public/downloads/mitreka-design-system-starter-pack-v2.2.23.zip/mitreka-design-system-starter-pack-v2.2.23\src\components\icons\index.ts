export { default as Icon } from "./Icon.vue";
export * from "./icons";
