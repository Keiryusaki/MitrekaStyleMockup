<template>
  <div class="h-dvh overflow-hidden">
    <template v-if="isBlankLayout">
      <router-view />
    </template>
    <template v-else>
      <AppLayout />
      <LoadingOverlay />
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { useRoute } from "vue-router";
import AppLayout from "./layouts/AppLayout.vue";
import LoadingOverlay from "@/components/LoadingOverlay.vue";

const route = useRoute();
const isBlankLayout = computed(() => route.meta.layout === "blank");
</script>
