export type CompareTheme =
  | "success"
  | "info"
  | "warning"
  | "primary"
  | "neutral"
  | "accent"
  | "secondary"
  | "error";
export type CompareRole = "header" | "row" | "total";

export type CompareRowMeta = {
  compareBlock?: string;
  compareRole?: CompareRole;
  compareTheme?: CompareTheme;
};

export type CompareRowClassOptions = {
  defaultTheme?: CompareTheme;
};

export type SpacerRowOptions = {
  rowType?: string;
  item?: string;
};

export type SpacerRowHeightOptions = {
  spacerHeight?: number;
  defaultHeight?: number;
  rowType?: string;
};

export const createCompareRowClassRules = (
  options: CompareRowClassOptions = {}
) => {
  const defaultTheme = options.defaultTheme ?? "success";
  const resolveTheme = (p: any): CompareTheme | undefined =>
    p.data?.compareTheme ?? defaultTheme;

  return {
    "cmp-block": (p: any) => !!p.data?.compareBlock,
    "cmp-role-header": (p: any) => p.data?.compareRole === "header",
    "cmp-role-total": (p: any) => p.data?.compareRole === "total",
    "cmp-theme-success": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "success",
    "cmp-theme-info": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "info",
    "cmp-theme-warning": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "warning",
    "cmp-theme-primary": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "primary",
    "cmp-theme-neutral": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "neutral",
    "cmp-theme-accent": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "accent",
    "cmp-theme-secondary": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "secondary",
    "cmp-theme-error": (p: any) =>
      !!p.data?.compareBlock && resolveTheme(p) === "error",
  };
};

export const createSpacerRow = (options: SpacerRowOptions = {}) => ({
  rowType: options.rowType ?? "spacer",
  item: options.item ?? "",
});

export const createSpacerRowClassRules = (rowType = "spacer") => ({
  "cmp-row-spacer": (p: any) => p.data?.rowType === rowType,
});

export const createSpacerRowHeight =
  (options: SpacerRowHeightOptions = {}) =>
  (params: any) => {
    const rowType = options.rowType ?? "spacer";
    const defaultHeight = options.defaultHeight ?? 26;
    const spacerHeight = options.spacerHeight ?? 24;
    return params?.data?.rowType === rowType ? spacerHeight : defaultHeight;
  };
