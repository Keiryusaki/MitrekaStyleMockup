# mitreka-consumer-test

Consumer app untuk validasi integrasi `@keiryusaki/mitreka-ui`.

## Prerequisite

1. Node.js 18+
2. Akses GitHub Packages untuk scope `@keiryusaki`
3. Personal Access Token (PAT) dengan scope yang diperlukan untuk read package

## Setup Auth (Tanpa Expose Token)

Jalankan token via environment variable di terminal (jangan commit token ke file):

```powershell
$env:GITHUB_TOKEN="ghp_xxx_your_token_here"
```

`.npmrc` project ini sudah pakai placeholder env var, jadi install akan membaca `GITHUB_TOKEN` dari sesi terminal.

## Install

```bash
npm install
```

## Run

```bash
npm run dev
```

## Build

```bash
npm run build
```

## Notes

1. AG Grid di project ini sudah pakai `AgGridSurface` dari package.
2. Styling AG Grid pakai import package:
`@keiryusaki/mitreka-ui/css/plugins/aggrid`.
3. Tidak ada file copy lokal seperti `aggrid-soft.css` atau `agTheme.ts`.
