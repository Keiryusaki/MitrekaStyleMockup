﻿<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { LoadingOverlay } from '@keiryusaki/mitreka-ui/vue'
import { useTheme } from '@keiryusaki/mitreka-ui/composables'
import AppLayout from './layouts/AppLayout.vue'

useTheme('light')

const route = useRoute()
const isBlank = computed(() => route.meta.layout === 'blank')
const globalLoading = ref(true)

let bootTimer = null
let routeTimer = null

onMounted(() => {
  bootTimer = window.setTimeout(() => {
    globalLoading.value = false
  }, 800)
})

watch(
  () => route.fullPath,
  (to, from) => {
    if (!from) return
    globalLoading.value = true
    if (routeTimer) window.clearTimeout(routeTimer)
    routeTimer = window.setTimeout(() => {
      globalLoading.value = false
    }, 300)
  }
)

onBeforeUnmount(() => {
  if (bootTimer) window.clearTimeout(bootTimer)
  if (routeTimer) window.clearTimeout(routeTimer)
})
</script>

<template>
  <LoadingOverlay :open="globalLoading" :size="140" text="Memuat aplikasi..." />
  <AppLayout v-if="!isBlank" />
  <router-view v-else />
</template>
