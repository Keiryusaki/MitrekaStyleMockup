import { createApp } from 'vue'
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community'
import './assets/tailwind.css'
import App from './App.vue'
import router from './router/index.js'

ModuleRegistry.registerModules([AllCommunityModule])

createApp(App).use(router).mount('#app')