<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { Icon } from '@keiryusaki/mitreka-ui/vue'

const props = defineProps({
  modelValue: { type: [String, Number, null], default: null },
  options: { type: Array, default: () => [] },
  placeholder: { type: String, default: 'Choose...' },
  disabled: { type: Boolean, default: false },
  size: { type: String, default: 'md' },
  color: { type: String, default: 'default' },
  variant: { type: String, default: 'solid' }
})

const emit = defineEmits(['update:modelValue', 'change'])

const root = ref(null)
const open = ref(false)
const hoverIdx = ref(-1)

const selected = computed(() => props.options.find((o) => o.value === props.modelValue) ?? null)
const displayText = computed(() => selected.value?.label ?? props.placeholder)

const sizeClasses = {
  xs: 'h-[var(--size-field-xs)] text-xs px-2 rounded-[var(--radius-field-xs)]',
  sm: 'h-[var(--size-field-sm)] text-sm px-2.5 rounded-[var(--radius-field-sm)]',
  md: 'h-[var(--size-field-md)] text-base px-3 rounded-[var(--radius-field-md)]',
  lg: 'h-[var(--size-field-lg)] text-lg px-3.5 rounded-[var(--radius-field-lg)]',
  xl: 'h-[var(--size-field-xl)] text-xl px-4 rounded-[var(--radius-field-xl)]'
}

const solidColorClasses = {
  default: 'bg-base-100 border-base-300 text-base-content hover:bg-base-200',
  primary: 'bg-primary border-primary text-primary-content hover:brightness-95',
  secondary: 'bg-secondary border-secondary text-secondary-content hover:brightness-95',
  accent: 'bg-accent border-accent text-accent-content hover:brightness-95',
  info: 'bg-info border-info text-info-content hover:brightness-95',
  success: 'bg-success border-success text-success-content hover:brightness-95',
  warning: 'bg-warning border-warning text-warning-content hover:brightness-95',
  error: 'bg-error border-error text-error-content hover:brightness-95'
}

const outlineColorClasses = {
  default: 'bg-transparent border-base-300 text-base-content hover:bg-base-200/40',
  primary: 'bg-transparent border-primary text-primary hover:bg-primary/10',
  secondary: 'bg-transparent border-secondary text-base-content hover:bg-secondary/10',
  accent: 'bg-transparent border-accent text-accent hover:bg-accent/10',
  info: 'bg-transparent border-info text-info hover:bg-info/10',
  success: 'bg-transparent border-success text-success hover:bg-success/10',
  warning: 'bg-transparent border-warning text-warning hover:bg-warning/10',
  error: 'bg-transparent border-error text-error hover:bg-error/10'
}

const focusRingColors = {
  default: 'ring-3 ring-primary/30 border-primary',
  primary: 'ring-3 ring-primary/30 border-primary',
  secondary: 'ring-3 ring-secondary/30 border-secondary',
  accent: 'ring-3 ring-accent/30 border-accent',
  info: 'ring-3 ring-info/30 border-info',
  success: 'ring-3 ring-success/30 border-success',
  warning: 'ring-3 ring-warning/30 border-warning',
  error: 'ring-3 ring-error/30 border-error'
}

const triggerClass = computed(() => {
  const base = 'w-full flex items-center justify-between gap-2 border cursor-pointer transition-all duration-150'
  const sizeClass = sizeClasses[props.size] || sizeClasses.md
  const colorClass = props.variant === 'outline'
    ? (outlineColorClasses[props.color] || outlineColorClasses.default)
    : (solidColorClasses[props.color] || solidColorClasses.default)
  const disabledClass = props.disabled ? 'opacity-60 cursor-not-allowed' : ''
  const focusClass = open.value ? (focusRingColors[props.color] || focusRingColors.default) : ''
  return [base, sizeClass, colorClass, disabledClass, focusClass].join(' ')
})

const itemSizeClasses = {
  xs: 'text-xs py-1.5 px-2',
  sm: 'text-sm py-1.5 px-2.5',
  md: 'text-base py-2 px-3',
  lg: 'text-lg py-2 px-3.5',
  xl: 'text-xl py-2.5 px-4'
}

const dropdownBgStyle = computed(() => {
  if (props.color === 'default') return { backgroundColor: 'var(--color-base-100)' }
  return { backgroundColor: `color-mix(in oklch, var(--color-${props.color}), white 85%)` }
})

const checkIconStyle = computed(() => {
  if (props.color === 'default') return { color: 'var(--color-primary)' }
  if (props.color === 'secondary') return { color: 'var(--color-secondary-content)' }
  return { color: `var(--color-${props.color})` }
})

const getItemStyle = (isHovered) => {
  const textColor = props.color === 'default'
    ? 'var(--color-base-content)'
    : props.color === 'secondary'
      ? 'var(--color-secondary-content)'
      : `var(--color-${props.color})`
  if (props.color === 'default') {
    return {
      color: textColor,
      backgroundColor: isHovered ? 'var(--color-base-200)' : 'transparent'
    }
  }
  return {
    color: textColor,
    backgroundColor: isHovered
      ? `color-mix(in oklch, var(--color-${props.color}), white 70%)`
      : 'transparent'
  }
}

const toggle = () => {
  if (props.disabled) return
  open.value = !open.value
  if (open.value) {
    hoverIdx.value = props.options.findIndex((o) => o.value === props.modelValue)
  }
}

const choose = (option) => {
  if (option.disabled) return
  emit('update:modelValue', option.value)
  emit('change', option.value)
  open.value = false
}

const onKey = (e) => {
  if (props.disabled) return
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault()
    if (open.value && hoverIdx.value >= 0) {
      const opt = props.options[hoverIdx.value]
      if (opt && !opt.disabled) choose(opt)
    } else {
      toggle()
    }
    return
  }
  if (e.key === 'Escape') {
    open.value = false
    return
  }
  if (e.key === 'ArrowDown') {
    e.preventDefault()
    if (!open.value) {
      open.value = true
      hoverIdx.value = 0
    } else {
      hoverIdx.value = Math.min(hoverIdx.value + 1, props.options.length - 1)
    }
    return
  }
  if (e.key === 'ArrowUp') {
    e.preventDefault()
    if (open.value) hoverIdx.value = Math.max(hoverIdx.value - 1, 0)
  }
}

const onClickOutside = (e) => {
  if (root.value && !root.value.contains(e.target)) {
    open.value = false
  }
}

onMounted(() => document.addEventListener('click', onClickOutside))
onBeforeUnmount(() => document.removeEventListener('click', onClickOutside))
</script>

<template>
  <div ref="root" class="relative">
    <button
      type="button"
      :class="triggerClass"
      :disabled="disabled"
      @click="toggle"
      @keydown="onKey"
    >
      <span :class="[!selected ? 'opacity-60' : '']">{{ displayText }}</span>
      <Icon
        :name="open ? 'chevron-up' : 'chevron-down'"
        class="w-4 h-4 shrink-0 transition-transform duration-200 pointer-events-none"
      />
    </button>

    <Transition
      enter-active-class="transition duration-150 ease-out"
      enter-from-class="opacity-0 -translate-y-1 scale-[0.98]"
      enter-to-class="opacity-100 translate-y-0 scale-100"
      leave-active-class="transition duration-100 ease-in"
      leave-from-class="opacity-100 translate-y-0 scale-100"
      leave-to-class="opacity-0 -translate-y-1 scale-[0.98]"
    >
      <div
        v-if="open"
        class="absolute z-50 mt-1 w-full rounded-box border border-base-300 shadow-lg p-1"
        :style="dropdownBgStyle"
      >
        <ul class="max-h-60 overflow-auto" role="listbox">
          <li
            v-for="(opt, i) in options"
            :key="opt.value"
            :class="[
              itemSizeClasses[size] || itemSizeClasses.md,
              'flex items-center justify-between cursor-pointer transition-colors duration-100 rounded-field',
              opt.disabled ? 'opacity-50 cursor-not-allowed' : '',
              selected?.value === opt.value ? 'font-medium' : ''
            ]"
            :style="getItemStyle(i === hoverIdx)"
            role="option"
            :aria-selected="selected?.value === opt.value"
            @mouseenter="hoverIdx = i"
            @click="opt.disabled ? null : choose(opt)"
          >
            <span>{{ opt.label }}</span>
            <Icon
              v-if="selected?.value === opt.value"
              name="check"
              class="w-4 h-4"
              :style="checkIconStyle"
            />
          </li>
        </ul>
      </div>
    </Transition>
  </div>
</template>
