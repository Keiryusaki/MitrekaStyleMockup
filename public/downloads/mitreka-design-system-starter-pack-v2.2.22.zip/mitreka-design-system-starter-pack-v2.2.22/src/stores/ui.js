﻿import { reactive } from 'vue'

const ui = reactive({
  sidebarOpen: false,
  sidebarCollapsed: false,
  openGroups: {},
  toggleSidebar() {
    ui.sidebarOpen = !ui.sidebarOpen
  },
  toggleSidebarCollapse() {
    ui.sidebarCollapsed = !ui.sidebarCollapsed
  },
  toggleGroup(id) {
    ui.openGroups[id] = !ui.openGroups[id]
  },
  setGroupOpen(id, open) {
    ui.openGroups[id] = open
  }
})

export function useUi() {
  return ui
}

