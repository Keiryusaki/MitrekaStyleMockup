<script setup>
import { ref } from 'vue'
import { PageHeader, LoadingLogo, LoadingOverlay } from '@keiryusaki/mitreka-ui/vue'

const cardRows = Array.from({ length: 3 }, (_, i) => i)
const tableRows = Array.from({ length: 5 }, (_, i) => i)
const showBlockLoading = ref(false)
const showGlobalLoading = ref(false)

const startBlockLoading = () => {
  showBlockLoading.value = true
  window.setTimeout(() => {
    showBlockLoading.value = false
  }, 1800)
}

const startGlobalLoading = () => {
  showGlobalLoading.value = true
  window.setTimeout(() => {
    showGlobalLoading.value = false
  }, 1800)
}
</script>

<template>
  <div class="space-y-6">
    <PageHeader
      category="Components"
      title="Skeleton"
      description="Loading placeholder untuk konten text, card, dan table."
    />

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Basic</h3>
      <div class="space-y-2 max-w-xl">
        <div class="skeleton h-4 w-1/2"></div>
        <div class="skeleton h-4 w-full"></div>
        <div class="skeleton h-4 w-5/6"></div>
      </div>
    </section>

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Card List</h3>
      <div class="grid md:grid-cols-3 gap-4">
        <article
          v-for="row in cardRows"
          :key="row"
          class="rounded-xl border border-base-300 p-4 space-y-3"
        >
          <div class="skeleton h-36 w-full rounded-lg"></div>
          <div class="skeleton h-4 w-3/4"></div>
          <div class="skeleton h-4 w-full"></div>
          <div class="skeleton h-4 w-2/3"></div>
        </article>
      </div>
    </section>

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Table Loading</h3>
      <div class="overflow-hidden rounded-lg border border-base-300">
        <div class="grid grid-cols-12 gap-3 p-3 border-b border-base-300 bg-base-200">
          <div class="skeleton h-4 col-span-1"></div>
          <div class="skeleton h-4 col-span-3"></div>
          <div class="skeleton h-4 col-span-3"></div>
          <div class="skeleton h-4 col-span-2"></div>
          <div class="skeleton h-4 col-span-3"></div>
        </div>
        <div
          v-for="row in tableRows"
          :key="row"
          class="grid grid-cols-12 gap-3 p-3 border-b border-base-300 last:border-b-0"
        >
          <div class="skeleton h-4 col-span-1"></div>
          <div class="skeleton h-4 col-span-3"></div>
          <div class="skeleton h-4 col-span-3"></div>
          <div class="skeleton h-4 col-span-2"></div>
          <div class="skeleton h-4 col-span-3"></div>
        </div>
      </div>
    </section>

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Block UI Loading</h3>
      <div class="flex flex-wrap gap-2">
        <button class="btn btn-outline btn-sm" type="button" @click="startBlockLoading">
          Simulate Block UI
        </button>
        <button class="btn btn-primary btn-sm" type="button" @click="startGlobalLoading">
          Simulate Global Overlay
        </button>
      </div>

      <div class="relative rounded-xl border border-base-300 p-4 min-h-40 overflow-hidden">
        <div class="space-y-2">
          <div class="font-medium">Area Content</div>
          <p class="text-sm opacity-70">
            Saat loading aktif, area ini diblok dengan overlay agar tidak bisa diinteraksi.
          </p>
          <div class="flex gap-2">
            <button class="btn btn-ghost btn-sm" type="button">Action 1</button>
            <button class="btn btn-ghost btn-sm" type="button">Action 2</button>
          </div>
        </div>

        <div
          v-if="showBlockLoading"
          class="absolute inset-0 z-10 grid place-items-center bg-base-100/70 backdrop-blur-[2px]"
        >
          <LoadingLogo :size="120" text="Memuat area..." />
        </div>
      </div>

      <LoadingOverlay :open="showGlobalLoading" :size="140" text="Memuat halaman..." />
    </section>
  </div>
</template>
