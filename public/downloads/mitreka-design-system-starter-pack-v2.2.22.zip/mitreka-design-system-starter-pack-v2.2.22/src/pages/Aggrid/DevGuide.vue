<template>
  <details class="card p-6 mt-10">
    <summary class="cursor-pointer text-sm font-medium">AG Grid - Dev Guide</summary>
    <div class="mt-3 rounded-xl border border-base-300 p-4 bg-base-200">
      <h3 class="text-lg font-semibold mb-2">AG Grid - Dev Guide (Package First)</h3>

      <ol class="space-y-6 list-decimal ml-5">
        <li>
          <h4 class="font-semibold">Install</h4>
          <pre v-pre class="code"><code>npm i ag-grid-community ag-grid-vue3 @keiryusaki/mitreka-ui
# atau: yarn add ag-grid-community ag-grid-vue3 @keiryusaki/mitreka-ui
# atau: pnpm add ag-grid-community ag-grid-vue3 @keiryusaki/mitreka-ui</code></pre>
        </li>

        <li>
          <h4 class="font-semibold">Import CSS</h4>
          <pre v-pre class="code"><code>import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-quartz.css'
import '@keiryusaki/mitreka-ui/css/plugins/aggrid'</code></pre>
          <p class="text-sm opacity-80 mt-2">
            Tidak perlu copy file <code>aggrid-soft.css</code> atau <code>agTheme.ts</code> ke project.
          </p>
        </li>

        <li>
          <h4 class="font-semibold">Use Wrapper</h4>
          <pre v-pre class="code"><code>import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community'
import { AgGridSurface } from '@keiryusaki/mitreka-ui/vue'

ModuleRegistry.registerModules([AllCommunityModule])

&lt;AgGridSurface
  :rowData="rowData"
  :columnDefs="columnDefs"
  :gridOptions="gridOptions"
  :autoRowHeight="false"
/&gt;</code></pre>
        </li>

        <li>
          <h4 class="font-semibold">Quick Filter & Export</h4>
          <pre v-pre class="code"><code>api.value?.setGridOption('quickFilterText', searchValue)
api.value?.exportDataAsCsv({ fileName: 'data.csv' })</code></pre>
        </li>
      </ol>
    </div>
  </details>
</template>
