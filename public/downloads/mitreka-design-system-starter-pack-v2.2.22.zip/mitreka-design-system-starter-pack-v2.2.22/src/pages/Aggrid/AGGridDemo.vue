<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { AgGridSurface } from '@keiryusaki/mitreka-ui/vue'
import SelectDropdown from '@/components/controls/SelectDropdown.vue'
import { PageHeader } from '@keiryusaki/mitreka-ui/vue'
import DevGuide from './DevGuide.vue'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-quartz.css'
import '@keiryusaki/mitreka-ui/css/plugins/aggrid'
import {
  attachPinnedShadowsToElement,
  createCompareRowClassRules,
  createSpacerRow,
  createSpacerRowClassRules,
  calcAgHeaderHeight,
  calcAgRowHeight,
  resolveAgFontPx
} from '@keiryusaki/mitreka-ui/composables'

const isDark = ref(false)
let htmlObs = null

const computeDark = () => {
  const html = document.documentElement
  const byClass = html.classList.contains('dark')
  const byData = (html.getAttribute('data-theme') || '').toLowerCase() === 'mitrekadark'
  isDark.value = byClass || byData
}

onMounted(() => {
  computeDark()
  htmlObs = new MutationObserver(computeDark)
  htmlObs.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class', 'data-theme']
  })
})
onBeforeUnmount(() => htmlObs?.disconnect())

const density = ref('cozy')
const striped = ref(true)
const search = ref('')
const themeClass = computed(() => (isDark.value ? 'ag-theme-quartz-dark' : 'ag-theme-quartz'))
const autoHeightThreshold = 15
const minRows = 10
const paginationHeight = 56
const agFontPx = ref(13)
const rowHeightOf = (dens = density.value) => calcAgRowHeight(agFontPx.value, dens)
const minGridHeight = computed(() => calcAgHeaderHeight(density.value) + rowHeightOf() * minRows + paginationHeight)
const displayedRowCount = ref(100)
const useAutoHeight = computed(() => displayedRowCount.value < autoHeightThreshold)
const mainGridWrapStyle = computed(() =>
  useAutoHeight.value
    ? { height: 'auto' }
    : { minHeight: `${minGridHeight.value}px`, height: '80vh' }
)

const gridKey = computed(() => `${isDark.value ? 'dark' : 'light'}|${density.value}|${striped.value}`)

const names = ['Alpha', 'Bravo', 'Charlie', 'Delta', 'Echo', 'Foxtrot', 'Golf', 'Hotel', 'India', 'Juliet']
const rowData = Array.from({ length: 100 }, (_, i) => {
  const n = i + 1
  const nm = names[i % names.length]
  const ch = String.fromCharCode(65 + (i % 26))
  const status = n % 3 === 0 ? 'Closed' : n % 2 === 0 ? 'Pending' : 'Active'
  const longDesc = 'Ini deskripsi yang sengaja dipanjangin biar nge-wrap sampai dua baris di kolom Description, jadi ada tambahan kata-kata biar lebih panjang dan pasti turun ke baris berikutnya.'
  return {
    id: n,
    no: n,
    code: i % 2 === 0 ? ch : ch + ch,
    name: nm,
    status,
    description: i === 0 ? `${nm} - ${longDesc}` : `${nm} description #${n}`
  }
})

const iconSvgs = {
  pencil:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></svg>',
  trash:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 11v6"/><path d="M14 11v6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>'
}

const columnDefs = computed(() => [
  {
    field: 'no',
    headerName: 'No',
    maxWidth: 90,
    filter: 'agNumberColumnFilter',
    pinned: 'left',
    lockPinned: true,
    lockPosition: true
  },
  {
    field: 'code',
    headerName: 'Code',
    filter: 'agTextColumnFilter',
    pinned: 'left',
    lockPinned: true,
    lockPosition: true
  },
  {
    field: 'status',
    headerName: 'Status',
    maxWidth: 140,
    cellClass: 'agx-cell-badge',
    cellRenderer: (params) => {
      const status = params.value
      const badge =
        status === 'Active'
          ? 'badge badge-inline badge-success badge-xxs'
          : status === 'Pending'
            ? 'badge badge-inline badge-warning badge-xxs'
            : 'badge badge-inline badge-error badge-xxs'
      const text = status || '-'
      return `<span class="${badge}">${text}</span>`
    }
  },
  { field: 'name', headerName: 'Name', filter: 'agTextColumnFilter' },
  {
    field: 'description',
    headerName: 'Description',
    filter: 'agTextColumnFilter',
    wrapText: true,
    autoHeight: true,
    cellStyle: { whiteSpace: 'normal', lineHeight: '1.3' }
  },
  {
    headerName: 'Actions',
    colId: 'actions',
    pinned: 'right',
    maxWidth: 160,
    suppressHeaderMenuButton: true,
    sortable: false,
    filter: false,
    cellRenderer: () => {
      const root = document.createElement('div')
      root.className = 'flex items-center justify-end gap-2 h-full'

      const sizeClass = density.value === 'compact' ? 'icon-btn-xs' : density.value === 'spacious' ? 'icon-btn-md' : 'icon-btn-sm'
      const mkBtn = (variant, title, svg) => {
        const b = document.createElement('button')
        b.type = 'button'
        b.className = `icon-btn icon-btn-solid-${variant} ${sizeClass}`
        b.title = title
        b.innerHTML = svg.replace('<svg', '<svg class="w-4 h-4"')
        b.addEventListener('click', (e) => e.stopPropagation())
        return b
      }

      root.append(mkBtn('warning', 'Edit', iconSvgs.pencil), mkBtn('error', 'Hapus', iconSvgs.trash))
      return root
    }
  }
])

const defaultColDef = {
  flex: 1,
  minWidth: 140,
  resizable: true,
  sortable: true,
  filter: true,
  floatingFilter: true
}

const gridOptions = {
  animateRows: true,
  rowSelection: {
    mode: 'multiRow',
    checkboxes: true,
    headerCheckbox: true,
    selectionColumn: {
      pinned: 'left',
      width: 56,
      resizable: false,
      suppressHeaderFilterButton: true,
      filter: false,
      floatingFilter: false
    }
  },
  pagination: true,
  paginationPageSize: 50,
  paginationPageSizeSelector: [50, 100]
}

const api = ref(null)
const pinnedShadowCleanups = []
const mainGridWrap = ref(null)
const compareGridWrap = ref(null)

function resolveVisibleRowCount(gridApi) {
  if (!gridApi) return rowData.length
  if (typeof gridApi.paginationGetRowCount === 'function') {
    const count = gridApi.paginationGetRowCount()
    if (Number.isFinite(count)) return count
  }
  if (typeof gridApi.getDisplayedRowCount === 'function') {
    const count = gridApi.getDisplayedRowCount()
    if (Number.isFinite(count)) return count
  }
  return rowData.length
}

function syncVisibleRowCount(gridApi = api.value) {
  displayedRowCount.value = Math.max(0, resolveVisibleRowCount(gridApi))
}

function applyDensityToApi() {
  if (!api.value) return
  const rowH = rowHeightOf()
  api.value.setGridOption('rowHeight', rowH)
  api.value.setGridOption('getRowHeight', () => rowH)
  api.value.setGridOption('domLayout', useAutoHeight.value ? 'autoHeight' : 'normal')
  api.value.resetRowHeights()
  api.value.refreshCells({ force: true })
}

const exportCsv = () => {
  api.value?.exportDataAsCsv({ fileName: 'aggrid-export.csv' })
}

function onGridReady(params) {
  api.value = params.api
  params.api.applyColumnState({
    state: [
      { colId: 'ag-Grid-SelectionColumn', pinned: 'left' },
      { colId: 'no', pinned: 'left' },
      { colId: 'code', pinned: 'left' }
    ],
    applyOrder: true
  })
  applyDensityToApi()
  params.api.setGridOption('quickFilterText', search.value)
  syncVisibleRowCount(params.api)
  ;['modelUpdated', 'paginationChanged', 'filterChanged'].forEach((eventName) =>
    params.api.addEventListener(eventName, () => syncVisibleRowCount(params.api))
  )
}

watch(density, (value) => {
  nextTick(() => {
    applyDensityToApi()
    syncVisibleRowCount()
    api.value?.refreshCells({ columns: ['actions'], force: true })
    if (compareApi.value) {
      const rowH = rowHeightOf(value)
      compareApi.value.setGridOption('rowHeight', rowH)
      compareApi.value.setGridOption('getRowHeight', (p) => (p?.data?.rowType === 'spacer' ? 24 : rowH))
      compareApi.value.resetRowHeights()
      compareApi.value.refreshCells({ force: true })
    }
  })
})

watch(useAutoHeight, (isAuto) => {
  if (!api.value) return
  api.value.setGridOption('domLayout', isAuto ? 'autoHeight' : 'normal')
})

watch(search, (value) => {
  api.value?.setGridOption('quickFilterText', value)
})

onMounted(async () => {
  await nextTick()
  agFontPx.value = resolveAgFontPx(mainGridWrap.value)
  applyDensityToApi()
  if (compareApi.value) {
    const rowH = rowHeightOf()
    compareApi.value.setGridOption('rowHeight', rowH)
    compareApi.value.setGridOption('getRowHeight', (p) => (p?.data?.rowType === 'spacer' ? 24 : rowH))
    compareApi.value.resetRowHeights()
    compareApi.value.refreshCells({ force: true })
  }
})

const fmt = new Intl.NumberFormat('id-ID')
const compareRowData = [
  {
    item: 'Plan/Bln',
    jan: -619978400,
    feb: 194694000,
    mar: 0,
    compareBlock: 'plan',
    compareRole: 'row',
    compareTheme: 'info'
  },
  {
    item: 'Acc.Plan',
    jan: -619978400,
    feb: -425284400,
    mar: -425284400,
    compareBlock: 'plan',
    compareRole: 'row',
    compareTheme: 'info'
  },
  createSpacerRow(),
  {
    item: 'Realisasi/Bln',
    jan: 0,
    feb: 0,
    mar: 0,
    compareBlock: 'realized',
    compareRole: 'row',
    compareTheme: 'success'
  },
  {
    item: 'Acc.Realisasi',
    jan: 0,
    feb: 0,
    mar: 0,
    compareBlock: 'realized',
    compareRole: 'row',
    compareTheme: 'success'
  }
]

const compareColumnDefs = [
  {
    field: 'item',
    headerName: 'Item',
    pinned: 'left',
    lockPinned: true,
    width: 180
  },
  {
    headerName: '2026',
    children: [
      {
        field: 'jan',
        headerName: 'Jan',
        valueFormatter: (p) => fmt.format(p.value ?? 0),
        cellClass: 'ag-right-aligned-cell',
        width: 120
      },
      {
        field: 'feb',
        headerName: 'Feb',
        valueFormatter: (p) => fmt.format(p.value ?? 0),
        cellClass: 'ag-right-aligned-cell',
        width: 120
      },
      {
        field: 'mar',
        headerName: 'Mar',
        valueFormatter: (p) => fmt.format(p.value ?? 0),
        cellClass: 'ag-right-aligned-cell',
        width: 120
      }
    ]
  }
]

const compareGridOptions = {
  animateRows: false,
  suppressHeaderMenuButton: true,
  domLayout: 'autoHeight',
  getRowHeight: (params) => (params?.data?.rowType === 'spacer' ? 24 : rowHeightOf())
}

const compareRowClassRules = createCompareRowClassRules({ defaultTheme: 'success' })
const compareSpacerRules = createSpacerRowClassRules()
const compareApi = ref(null)

function onCompareGridReady(params) {
  compareApi.value = params.api
  compareApi.value.setGridOption('rowHeight', rowHeightOf())
  compareApi.value.resetRowHeights()
  params.api.sizeColumnsToFit()
}

onMounted(async () => {
  await nextTick()
  if (mainGridWrap.value) {
    pinnedShadowCleanups.push(attachPinnedShadowsToElement(mainGridWrap.value))
  }
  if (compareGridWrap.value) {
    pinnedShadowCleanups.push(attachPinnedShadowsToElement(compareGridWrap.value))
  }
})

onBeforeUnmount(() => {
  pinnedShadowCleanups.splice(0).forEach((cleanup) => cleanup())
})
</script>

<template>
  <div class="space-y-6 flex-1 flex flex-col min-h-0">
    <PageHeader category="Mockup" title="AG Grid" description="Contoh implementasi AG Grid dengan theme dan density controls." />

    <div class="card p-2">
      <div class="flex flex-wrap items-center gap-3">
        <div class="flex items-center gap-2 w-full sm:w-auto">
          <input v-model="search" type="text" placeholder="Search..." class="input w-64 max-w-full" />
          <button class="btn btn-ghost btn-sm" type="button" :disabled="!search" @click="search = ''">Clear</button>
        </div>
        <button class="btn btn-outline btn-sm" type="button" @click="exportCsv">Export CSV</button>
        <div class="flex items-center gap-2">
          <span class="text-sm opacity-70">Density</span>
          <SelectDropdown
            v-model="density"
            :options="[
              { value: 'compact', label: 'Compact' },
              { value: 'cozy', label: 'Cozy' },
              { value: 'spacious', label: 'Spacious' }
            ]"
            size="sm"
            variant="outline"
          />
        </div>
        <label class="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" v-model="striped" />
          <span>Striped</span>
        </label>
      </div>
    </div>

    <div ref="mainGridWrap" class="w-full" :style="mainGridWrapStyle">
      <AgGridSurface
        :auto-row-height="false"
        :pinned-shadows="false"
        :density="density"
        :key="gridKey"
        :class="['agx', themeClass, 'w-full', 'h-full', 'min-h-0']"
        theme="legacy"
        :style="{
          '--ag-odd-row-background-color': striped ? (isDark ? '#0d1a33' : '#F3F4F6') : 'transparent'
        }"
        :rowData="rowData"
        :columnDefs="columnDefs"
        :defaultColDef="defaultColDef"
        :rowHeight="rowHeightOf()"
        :gridOptions="gridOptions"
        :domLayout="useAutoHeight ? 'autoHeight' : 'normal'"
        @grid-ready="onGridReady"
      />
    </div>

    <section class="card p-4 space-y-3">
      <div class="text-sm font-semibold">Compare Rows (Visual)</div>
      <div class="text-xs opacity-70">
        Tambahkan spacer dengan helper <code>createSpacerRow()</code>, aktifkan class rules via
        <code>createSpacerRowClassRules()</code>, dan set tinggi row dengan <code>createSpacerRowHeight()</code>.
      </div>
      <div class="text-xs opacity-70">
        Garis tebal di header dikontrol di <code>@keiryusaki/mitreka-ui/css/plugins/aggrid</code> (header separator 3px).
      </div>
      <div class="w-full" ref="compareGridWrap">
        <AgGridSurface
          :auto-row-height="false"
          :pinned-shadows="false"
          :density="density"
          :class="['agx', themeClass, 'w-full']"
          theme="legacy"
          :style="{
            '--ag-odd-row-background-color': striped ? (isDark ? '#0d1a33' : '#F3F4F6') : 'transparent'
          }"
          :rowData="compareRowData"
          :columnDefs="compareColumnDefs"
          :defaultColDef="{
            resizable: true,
            sortable: false,
            filter: false,
            floatingFilter: false,
            suppressHeaderMenuButton: true
          }"
          :rowHeight="rowHeightOf()"
          :gridOptions="compareGridOptions"
          :rowClassRules="{ ...compareRowClassRules, ...compareSpacerRules }"
          @grid-ready="onCompareGridReady"
        />
      </div>
    </section>

    <DevGuide />
  </div>
</template>
