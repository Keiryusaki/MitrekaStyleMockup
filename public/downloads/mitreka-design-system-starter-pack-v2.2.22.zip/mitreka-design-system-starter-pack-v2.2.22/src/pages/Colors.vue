﻿<script setup>
import { ref } from 'vue'
import FloatingTOC from '../components/FloatingTOC.vue'
import { PageHeader } from '@keiryusaki/mitreka-ui/vue'

const tocItems = [
  { id: 'state-colors', label: 'State Colors' },
  { id: 'base-colors', label: 'Base Colors' },
  { id: 'usage-css', label: 'CSS Variables' },
  { id: 'usage-tailwind', label: 'Tailwind Classes' },
  { id: 'soft-variants', label: 'Soft Variants' },
  { id: 'theme-definition', label: 'Theme Definition' }
]

const copiedId = ref(null)

const copyCode = async (code, id) => {
  await navigator.clipboard.writeText(code)
  copiedId.value = id
  setTimeout(() => (copiedId.value = null), 2000)
}

const stateColors = [
  { name: 'primary', var: '--color-primary', desc: 'Brand utama, CTA, links' },
  { name: 'secondary', var: '--color-secondary', desc: 'Secondary actions' },
  { name: 'accent', var: '--color-accent', desc: 'Highlight, decorative' },
  { name: 'info', var: '--color-info', desc: 'Informasi, tips' },
  { name: 'success', var: '--color-success', desc: 'Berhasil, valid, positive' },
  { name: 'warning', var: '--color-warning', desc: 'Peringatan, attention' },
  { name: 'error', var: '--color-error', desc: 'Error, invalid, destructive' },
  { name: 'neutral', var: '--color-neutral', desc: 'Netral, disabled' }
]

const baseColors = [
  { name: 'base-100', var: '--color-base-100', desc: 'Background utama' },
  { name: 'base-200', var: '--color-base-200', desc: 'Background secondary' },
  { name: 'base-300', var: '--color-base-300', desc: 'Border, divider' },
  { name: 'base-content', var: '--color-base-content', desc: 'Text utama' }
]

const codes = {
  cssVars: `/* Akses via CSS variable */\n.my-element {\n  background: var(--color-primary);\n  color: var(--color-primary-content);\n  border-color: var(--color-base-300);\n}`,
  tailwindClasses: `<!-- Tailwind classes -->\n<div class="bg-primary text-primary-content">Primary</div>\n<div class="bg-success text-success-content">Success</div>\n<div class="bg-error text-error-content">Error</div>\n<div class="bg-warning text-warning-content">Warning</div>\n<div class="bg-info text-info-content">Info</div>\n\n<!-- Base colors -->\n<div class="bg-base-100">Background</div>\n<div class="bg-base-200">Card background</div>\n<div class="border-base-300">Border</div>\n<div class="text-base-content">Text</div>`,
  softVariants: `<!-- Soft variants (background dengan opacity) -->\n<span class="badge badge-soft-primary">Primary</span>\n<span class="badge badge-soft-success">Success</span>\n<span class="badge badge-soft-error">Error</span>\n<span class="badge badge-soft-warning">Warning</span>\n<span class="badge badge-soft-info">Info</span>\n\n<!-- Button soft -->\n<button class="btn btn-soft-primary">Soft Primary</button>\n<button class="btn btn-soft-error">Soft Error</button>`,
  colorMix: `/* Custom opacity dengan color-mix */\n.soft-bg {\n  background: color-mix(in oklch, var(--color-primary), transparent 88%);\n}\n\n.hover-bg:hover {\n  background: color-mix(in oklch, var(--color-primary), white 85%);\n}`,
  themeDefinition: `/* src/assets/tailwind.css */\n:root[data-theme="mitrekalight"] {\n  --color-primary: #025097;\n  --color-primary-content: oklch(93% 0.034 272.788);\n\n  --color-success: oklch(69% 0.17 162.48);\n  --color-success-content: oklch(100% 0 0);\n\n  --color-warning: oklch(70% 0.213 47.604);\n  --color-warning-content: oklch(100% 0 0);\n\n  --color-error: #ee3032;\n  --color-error-content: oklch(100% 0 0);\n\n  --color-info: oklch(68% 0.169 237.323);\n  --color-info-content: oklch(100% 0 0);\n\n  /* Base */\n  --color-base-100: oklch(100% 0 0);\n  --color-base-200: #f3f4f6;\n  --color-base-300: oklch(95% 0 0);\n  --color-base-content: oklch(21% 0.006 285.885);\n}`
}
</script>

<template>
  <div class="space-y-8">
    <PageHeader
      category="Foundation"
      title="Colors & Palette"
      description="State colors dan base colors untuk design system Mitreka."
    />

    <section id="state-colors" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">State Colors</h2>
      <p class="text-sm opacity-80">
        Warna semantik untuk feedback dan status. Setiap warna punya <code class="code-inline">-content</code> untuk text kontras.
      </p>

      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div v-for="color in stateColors" :key="color.name" class="space-y-2">
          <div class="h-20 rounded-box flex items-end p-2" :class="`bg-${color.name}`">
            <span :class="`text-${color.name}-content text-xs font-medium`">
              {{ color.name }}
            </span>
          </div>
          <div class="text-xs">
            <code class="code-inline">{{ color.var }}</code>
            <p class="opacity-60 mt-1">{{ color.desc }}</p>
          </div>
        </div>
      </div>
    </section>

    <section id="base-colors" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Base Colors</h2>
      <p class="text-sm opacity-80">Warna dasar untuk background, border, dan text. Otomatis berubah sesuai theme.</p>

      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div v-for="color in baseColors" :key="color.name" class="space-y-2">
          <div class="h-20 rounded-box border border-base-300 flex items-end p-2" :class="`bg-${color.name}`">
            <span class="text-base-content text-xs font-medium">{{ color.name }}</span>
          </div>
          <div class="text-xs">
            <code class="code-inline">{{ color.var }}</code>
            <p class="opacity-60 mt-1">{{ color.desc }}</p>
          </div>
        </div>
      </div>
    </section>

    <section id="usage-css" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Base Colors: Light vs Dark</h2>
      <p class="text-sm opacity-80">Perbandingan base colors antara light dan dark theme.</p>

      <div class="grid md:grid-cols-2 gap-4">
        <div class="rounded-box overflow-hidden border border-base-300">
          <div class="px-4 py-2 bg-base-200 font-medium text-sm">Light Theme</div>
          <div class="p-4 space-y-2" style="background: #ffffff;">
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #ffffff; border: 1px solid #e5e5e5;"></div>
              <div class="text-xs" style="color: #1a1a1a;">
                <code>base-100</code> <span class="opacity-60">#ffffff</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #f3f4f6;"></div>
              <div class="text-xs" style="color: #1a1a1a;">
                <code>base-200</code> <span class="opacity-60">#f3f4f6</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #e5e5e5;"></div>
              <div class="text-xs" style="color: #1a1a1a;">
                <code>base-300</code> <span class="opacity-60">#e5e5e5</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded flex items-center justify-center" style="background: #1a1a1a;">
                <span class="text-white text-xs">Aa</span>
              </div>
              <div class="text-xs" style="color: #1a1a1a;">
                <code>base-content</code> <span class="opacity-60">#1a1a1a</span>
              </div>
            </div>
          </div>
        </div>

        <div class="rounded-box overflow-hidden border border-base-300">
          <div class="px-4 py-2 bg-base-200 font-medium text-sm">Dark Theme</div>
          <div class="p-4 space-y-2" style="background: #1e1b4b;">
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #1e1b4b; border: 1px solid #4338ca;"></div>
              <div class="text-xs" style="color: #f5f5f5;">
                <code>base-100</code> <span class="opacity-60">#1e1b4b</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #312e81;"></div>
              <div class="text-xs" style="color: #f5f5f5;">
                <code>base-200</code> <span class="opacity-60">#312e81</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded" style="background: #4338ca;"></div>
              <div class="text-xs" style="color: #f5f5f5;">
                <code>base-300</code> <span class="opacity-60">#4338ca</span>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-8 rounded flex items-center justify-center" style="background: #f5f5f5;">
                <span class="text-xs" style="color: #1e1b4b;">Aa</span>
              </div>
              <div class="text-xs" style="color: #f5f5f5;">
                <code>base-content</code> <span class="opacity-60">#f5f5f5</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="soft-variants" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Soft Variants</h2>
      <p class="text-sm opacity-80">Versi "soft" dengan background transparan - cocok untuk badge dan button subtle.</p>

      <div class="flex flex-wrap gap-2">
        <span class="badge badge-soft-primary">Primary</span>
        <span class="badge badge-soft-secondary">Secondary</span>
        <span class="badge badge-soft-accent">Accent</span>
        <span class="badge badge-soft-info">Info</span>
        <span class="badge badge-soft-success">Success</span>
        <span class="badge badge-soft-warning">Warning</span>
        <span class="badge badge-soft-error">Error</span>
      </div>

      <div class="flex flex-wrap gap-2 mt-4">
        <button class="btn btn-soft-primary btn-sm">Soft Primary</button>
        <button class="btn btn-soft-success btn-sm">Soft Success</button>
        <button class="btn btn-soft-warning btn-sm">Soft Warning</button>
        <button class="btn btn-soft-error btn-sm">Soft Error</button>
        <button class="btn btn-soft-info btn-sm">Soft Info</button>
      </div>

      <div class="code-block mt-4">
        <button class="copy-btn" @click="copyCode(codes.softVariants, 'softVariants')">
          {{ copiedId === 'softVariants' ? '? Copied!' : 'Copy' }}
        </button>
        <pre><code>{{ codes.softVariants }}</code></pre>
      </div>
    </section>

    <section id="usage-tailwind" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Usage: CSS Variables</h2>
      <p class="text-sm opacity-80">Akses warna via CSS variables untuk custom styling.</p>

      <div class="code-block">
        <button class="copy-btn" @click="copyCode(codes.cssVars, 'cssVars')">
          {{ copiedId === 'cssVars' ? '? Copied!' : 'Copy' }}
        </button>
        <pre><code>{{ codes.cssVars }}</code></pre>
      </div>
    </section>

    <section class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Usage: Tailwind Classes</h2>
      <p class="text-sm opacity-80">Gunakan utility classes Tailwind untuk apply warna.</p>

      <div class="code-block">
        <button class="copy-btn" @click="copyCode(codes.tailwindClasses, 'tailwindClasses')">
          {{ copiedId === 'tailwindClasses' ? '? Copied!' : 'Copy' }}
        </button>
        <pre><code>{{ codes.tailwindClasses }}</code></pre>
      </div>
    </section>

    <section class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Custom Opacity dengan color-mix</h2>
      <p class="text-sm opacity-80">Gunakan <code class="code-inline">color-mix()</code> untuk custom opacity tanpa class baru.</p>

      <div class="code-block">
        <button class="copy-btn" @click="copyCode(codes.colorMix, 'colorMix')">
          {{ copiedId === 'colorMix' ? '? Copied!' : 'Copy' }}
        </button>
        <pre><code>{{ codes.colorMix }}</code></pre>
      </div>
    </section>

    <section id="theme-definition" class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Theme Definition</h2>
      <p class="text-sm opacity-80">Definisi warna di <code class="code-inline">tailwind.css</code> menggunakan CSS variables.</p>

      <div class="code-block">
        <button class="copy-btn" @click="copyCode(codes.themeDefinition, 'themeDefinition')">
          {{ copiedId === 'themeDefinition' ? '? Copied!' : 'Copy' }}
        </button>
        <pre><code>{{ codes.themeDefinition }}</code></pre>
      </div>
    </section>

    <section class="card p-6 space-y-4 scroll-mt-20">
      <h2 class="text-lg font-semibold border-b border-base-300 pb-2">Quick Reference</h2>

      <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-base-200">
            <tr>
              <th class="px-4 py-2 text-left">Color</th>
              <th class="px-4 py-2 text-left">Background</th>
              <th class="px-4 py-2 text-left">Text</th>
              <th class="px-4 py-2 text-left">Border</th>
              <th class="px-4 py-2 text-left">Soft BG</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-base-200">
            <tr v-for="color in stateColors" :key="color.name">
              <td class="px-4 py-2 font-medium">{{ color.name }}</td>
              <td class="px-4 py-2"><code class="code-inline">bg-{{ color.name }}</code></td>
              <td class="px-4 py-2"><code class="code-inline">text-{{ color.name }}</code></td>
              <td class="px-4 py-2"><code class="code-inline">border-{{ color.name }}</code></td>
              <td class="px-4 py-2"><code class="code-inline">badge-soft-{{ color.name }}</code></td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <FloatingTOC :items="tocItems" />
  </div>
</template>

<style scoped>
.code-block {
  position: relative;
  background: var(--color-base-200);
  border: 1px solid var(--color-base-300);
  border-radius: var(--radius-box);
  overflow: hidden;
}
.code-block pre {
  padding: 1rem;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.5;
  margin: 0;
}
.code-block code {
  font-family: ui-monospace, monospace;
}
.copy-btn {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  padding: 0.25rem 0.75rem;
  font-size: 12px;
  background: var(--color-base-300);
  border: none;
  border-radius: var(--radius-field-sm);
  cursor: pointer;
  opacity: 0.8;
  transition: opacity 0.15s, background 0.15s;
}
.copy-btn:hover {
  opacity: 1;
  background: var(--color-primary);
  color: var(--color-primary-content);
}
.code-inline {
  background: var(--color-base-200);
  padding: 0.125rem 0.375rem;
  border-radius: 4px;
  font-size: 0.875em;
  font-family: ui-monospace, monospace;
}
</style>

