<script setup>
import { ref } from 'vue'
import { LoadingLogo, LoadingOverlay, PageHeader } from '@keiryusaki/mitreka-ui/vue'

const showBlockLoading = ref(false)
const showGlobalLoading = ref(false)

const startBlockLoading = () => {
  showBlockLoading.value = true
  window.setTimeout(() => {
    showBlockLoading.value = false
  }, 2000)
}

const startGlobalLoading = () => {
  showGlobalLoading.value = true
  window.setTimeout(() => {
    showGlobalLoading.value = false
  }, 2000)
}
</script>

<template>
  <div class="space-y-6">
    <PageHeader
      category="Components"
      title="Loading"
      description="Demo block loading area dan global loading overlay."
    />

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Actions</h3>
      <div class="flex gap-2">
        <button class="btn btn-outline btn-sm" type="button" @click="startBlockLoading">
          Simulate Block UI
        </button>
        <button class="btn btn-primary btn-sm" type="button" @click="startGlobalLoading">
          Simulate Global Overlay
        </button>
      </div>
    </section>

    <section class="card p-5 space-y-4">
      <h3 class="font-semibold">Block UI (Area)</h3>
      <div class="relative min-h-48 rounded-xl border border-base-300 p-4 overflow-hidden">
        <div class="space-y-3">
          <p class="text-sm opacity-70">
            Area ini tetap menampilkan konten, tapi diblok overlay saat loading aktif.
          </p>
          <div class="grid sm:grid-cols-3 gap-3">
            <div class="rounded-lg border border-base-300 p-3">Card A</div>
            <div class="rounded-lg border border-base-300 p-3">Card B</div>
            <div class="rounded-lg border border-base-300 p-3">Card C</div>
          </div>
        </div>

        <div
          v-if="showBlockLoading"
          class="absolute inset-0 z-10 grid place-items-center bg-base-100/70 backdrop-blur-[2px]"
        >
          <LoadingLogo :size="130" text="Memuat area..." />
        </div>
      </div>
    </section>

    <LoadingOverlay :open="showGlobalLoading" :size="150" text="Memuat halaman..." />
  </div>
</template>
