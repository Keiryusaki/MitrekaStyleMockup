﻿import { ref, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUi } from '../stores/ui'

export const NAV = [
  { id: 'dash', label: 'Dashboard', icon: 'dashboard', to: '/', exact: true },
  {
    id: 'mockup',
    label: 'Mockup Pages',
    icon: 'layout',
    children: [
      { id: 'aggrid', label: 'AG Grid', to: '/aggrid' },
      { id: 'project-budgeting', label: 'Project Budgeting', to: '/project-budgeting' }
    ]
  },
  {
    id: 'components',
    label: 'Components',
    icon: 'component',
    children: [
      { id: 'colors', label: 'Colors', to: '/colors' },
      { id: 'button', label: 'Button', to: '/button' },
      { id: 'input', label: 'Input', to: '/input' },
      { id: 'skeleton', label: 'Skeleton', to: '/skeleton' },
      { id: 'loading', label: 'Loading', to: '/loading' }
    ]
  },
  {
    id: 'auth',
    label: 'Auth Pages',
    icon: 'lock',
    children: [
      { id: 'auth-signin', label: 'Sign In', to: '/auth/signin' },
      { id: 'auth-register', label: 'Register', to: '/auth/register' },
      { id: 'auth-forgot', label: 'Forgot Password', to: '/auth/forgot' },
      { id: 'auth-reset', label: 'Reset Password', to: '/auth/reset' }
    ]
  }
]

const tip = ref({ show: false, text: '', x: 0, y: 0 })
const searchQuery = ref('')

export function useSidebar() {
  const ui = useUi()
  const router = useRouter()
  const route = useRoute()

  const normalizePath = (value) => {
    if (!value) return '/'
    const trimmed = value.replace(/\/+$/, '')
    return trimmed || '/'
  }
  const match = (path, item) => {
    const current = normalizePath(route.path)
    const target = normalizePath(path)
    if (item.exact) return current === target
    return current === target || current.startsWith(`${target}/`)
  }
  const isActive = (item) => (item.to ? match(item.to, item) : false)

  const isGroupOpen = (item) => {
    if (!item.children) return false
    if (searchQuery.value.trim()) return true

    const current = ui.openGroups[item.id]
    const auto = item.children?.some(isActive) ?? false
    if (current === undefined && auto) ui.setGroupOpen(item.id, true)
    return ui.openGroups[item.id] ?? auto
  }

  const toggleGroup = (item) => ui.toggleGroup(item.id)

  const go = (item) => {
    if (item.to) router.push(item.to)
    searchQuery.value = ''
    ui.sidebarOpen = false
  }

  const filteredNav = computed(() => {
    const query = searchQuery.value.toLowerCase().trim()
    if (!query) return NAV

    return NAV.map((item) => {
      if (item.children) {
        const matchingChildren = item.children.filter((child) =>
          child.label.toLowerCase().includes(query)
        )
        if (item.label.toLowerCase().includes(query)) return item
        if (matchingChildren.length > 0) return { ...item, children: matchingChildren }
        return null
      }
      return item.label.toLowerCase().includes(query) ? item : null
    }).filter(Boolean)
  })

  const setSearchQuery = (query) => {
    searchQuery.value = query
  }

  const clearSearch = () => {
    searchQuery.value = ''
  }

  function showTip(e, text) {
    if (!ui.sidebarCollapsed) return
    const el = e.currentTarget
    const r = el.getBoundingClientRect()
    tip.value = {
      show: true,
      text,
      x: r.right + 10,
      y: r.top + r.height / 2
    }
  }

  function hideTip() {
    tip.value.show = false
  }

  return {
    ui,
    isActive,
    isGroupOpen,
    toggleGroup,
    go,
    searchQuery,
    filteredNav,
    setSearchQuery,
    clearSearch,
    tip,
    showTip,
    hideTip
  }
}


