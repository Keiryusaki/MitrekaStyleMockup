<template>
  <div class="h-full bg-base-100 text-base-content grid" style="grid-template-rows: auto 1fr">
    <Topbar class="sticky top-0 z-30 glass" />

    <div class="grid overflow-hidden min-h-0 grid-cols-1 md:grid-cols-[auto_1fr]">
      <Sidebar />

      <main ref="mainContent" class="overflow-y-auto min-h-0 bg-base-200 flex flex-col">
        <div class="flex-1 p-4 md:p-6">
          <Breadcrumbs v-if="!route.meta.hideBreadcrumbs" class="mb-4" :items="breadcrumbs" />
          <router-view />
        </div>
        <Footer />
      </main>
    </div>

    <Toasts />
  </div>
</template>

<script setup>
import { ref, watch, computed } from 'vue'
import { useRoute } from 'vue-router'
import { Breadcrumbs, Toasts } from '@keiryusaki/mitreka-ui/vue'
import Sidebar from '../components/nav/Sidebar.vue'
import Topbar from '../components/nav/Topbar.vue'
import Footer from '../components/nav/Footer.vue'

const route = useRoute()
const mainContent = ref(null)
const breadcrumbs = computed(() => route.meta.breadcrumbs || [])

watch(
  () => route.path,
  () => {
    if (mainContent.value) {
      mainContent.value.scrollTo({ top: 0 })
    }
  }
)
</script>
