﻿import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../pages/Dashboard.vue'
import Colors from '../pages/Colors.vue'
import Buttons from '../pages/Buttons.vue'
import Input from '../pages/Input.vue'
import Skeleton from '../pages/Skeleton.vue'
import Loading from '../pages/Loading.vue'
import AGGridDemo from '../pages/Aggrid/AGGridDemo.vue'
import ProjectBudgeting from '../pages/Aggrid/ProjectBudgeting.vue'
import SignIn from '../pages/Auth/SignIn.vue'
import Register from '../pages/Auth/Register.vue'
import ForgotPassword from '../pages/Auth/ForgotPassword.vue'
import ResetPassword from '../pages/Auth/ResetPassword.vue'

const routes = [
  {
    path: '/',
    component: Dashboard,
    meta: { breadcrumbs: [] }
  },
  {
    path: '/colors',
    component: Colors,
    meta: { breadcrumbs: [{ label: 'Components', href: '/colors' }, { label: 'Colors' }] }
  },
  {
    path: '/button',
    component: Buttons,
    meta: { breadcrumbs: [{ label: 'Components', href: '/button' }, { label: 'Button' }] }
  },
  {
    path: '/input',
    component: Input,
    meta: { breadcrumbs: [{ label: 'Components', href: '/input' }, { label: 'Input' }] }
  },
  {
    path: '/skeleton',
    component: Skeleton,
    meta: { breadcrumbs: [{ label: 'Components', href: '/skeleton' }, { label: 'Skeleton' }] }
  },
  {
    path: '/loading',
    component: Loading,
    meta: { breadcrumbs: [{ label: 'Components', href: '/loading' }, { label: 'Loading' }] }
  },
  {
    path: '/aggrid',
    component: AGGridDemo,
    meta: { breadcrumbs: [{ label: 'Mockup Pages', href: '/aggrid' }, { label: 'AG Grid' }] }
  },
  {
    path: '/project-budgeting',
    component: ProjectBudgeting,
    meta: {
      breadcrumbs: [{ label: 'Mockup Pages', href: '/project-budgeting' }, { label: 'Project Budgeting' }],
      hideBreadcrumbs: true
    }
  },
  {
    path: '/auth/signin',
    component: SignIn,
    meta: { layout: 'blank' }
  },
  {
    path: '/auth/register',
    component: Register,
    meta: { layout: 'blank' }
  },
  {
    path: '/auth/forgot',
    component: ForgotPassword,
    meta: { layout: 'blank' }
  },
  {
    path: '/auth/reset',
    component: ResetPassword,
    meta: { layout: 'blank' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0 }
  }
})

export default router


