﻿import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    dedupe: ['vue', 'ag-grid-community', 'ag-grid-vue3'],
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      'ag-grid-community': fileURLToPath(new URL('./node_modules/ag-grid-community', import.meta.url)),
      'ag-grid-vue3': fileURLToPath(new URL('./node_modules/ag-grid-vue3', import.meta.url)),
    },
  },
})


