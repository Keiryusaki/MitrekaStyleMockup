﻿/** Tailwind v4 uses a separate PostCSS plugin package */
export default {
  plugins: {
    "@tailwindcss/postcss": {},
    autoprefixer: {},
  },
};


